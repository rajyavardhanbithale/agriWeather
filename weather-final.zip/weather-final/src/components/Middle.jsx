import React from "react";
import "./main.css";

function Middle(props) {
  const { temperature } = props;

  return (
    <>
      <div className="weather-by-hour">
        <h2 className="weather-by-hour__heading">Today's weather</h2>
        <div className="weather-by-hour__container">
          {temperature.map((temp, index) => (
            <div className="weather-by-hour__item" key={index}>
              <div className="weather-by-hour__hour">{index + 1}am</div>
              <img src="icons/mostly-sunny.svg" alt="Mostly sunny" />
              <div>{temp}&deg;</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Middle;
