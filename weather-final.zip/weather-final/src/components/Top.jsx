import React from "react";

import './main.css'


function Top(props) {
    const {city, day, date, temperature,temperatureMax, temperatureMin, 
                weatherDescription, winSpeed, rain,
                sunrise,sunset} = props;
    return (
        <>
            <main className="main-container">

                <div className="location-and-date">
                    <h1 className="location-and-date__location">{city}</h1>
                    <div>{day}, {date}</div>
                </div>


                <div className="current-temperature">
                    <div className="current-temperature__icon-container">
                        <img src="icons/mostly-sunny.svg" className="current-temperature__icon" alt="" />
                    </div>
                    <div className="current-temperature__content-container">
                        <div className="current-temperature__value">{temperature} &deg;</div>
                        <div className="current-temperature__summary">{weatherDescription}</div>
                    </div>
                </div>


                <div className="current-stats">
                    <div>
                        <div className="current-stats__value">{temperatureMax}&deg;</div>
                        <div className="current-stats__label">High</div>
                        <div className="current-stats__value">{temperatureMin}&deg;</div>
                        <div className="current-stats__label">Low</div>
                    </div>
                    <div>
                        <div className="current-stats__value">{winSpeed}mph</div>
                        <div className="current-stats__label">Wind</div>
                        <div className="current-stats__value">{rain}%</div>
                        <div className="current-stats__label">Rain</div>
                    </div>
                    <div>
                        <div className="current-stats__value">{sunrise}</div>
                        <div className="current-stats__label">Sunrise</div>
                        <div className="current-stats__value">{sunset}</div>
                        <div className="current-stats__label">Sunset</div>
                    </div>
                </div>

            </main>

        </>
        )
}


export default Top;