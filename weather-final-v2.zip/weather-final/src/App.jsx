import { useState, useEffect } from 'react'


import CompileWeather from './components/CompileWeather'

function App() {

  return (

    <>
      {/* <Top />
      <Middle/>
      <Bottom   imageSrc={newImageSrc} /> */}

      <CompileWeather />

    </>
  )
}

export default App
