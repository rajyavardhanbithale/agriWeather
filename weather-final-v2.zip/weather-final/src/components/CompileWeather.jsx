import React from "react";
import { useState, useEffect } from 'react'

import Top from "./Top";
import Middle from "./Middle";
import Bottom from "./Bottom";


function UserLocation() {

}


function CompileWeather() {
    const [latitude, setLatitude] = useState(null);
    const [longitude, setLongitude] = useState(null);

    //=============User Location==========
    useEffect(() => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                setLatitude(position.coords.latitude);
                setLongitude(position.coords.longitude);
            }, error => {
                console.error(error);
            });
        } else {
            console.error("Geolocation is not supported by this browser.");
        }
    }, []);


    // ===================== TOP Current Fetching API ==========================
    const [data, setData] = useState(null);
    const [data2, setData2] = useState(null);

    useEffect(() => {
        if (latitude && longitude) {
            const url = `http://localhost:8000/weather?lat=${latitude}&long=${longitude}`;
            fetch(url)
                .then(response => response.json())
                .then(data => setData(data))
                .catch(error => console.error(error));


            // ===================== Middle Future N Hour Fetching API ==========================
            const url2 = `http://localhost:8000/forecastndays?lat=${latitude}&long=${longitude}&days=7`;
            fetch(url2)
                .then(response => response.json())
                .then(data2 => setData2(data2))
                .catch(error => console.error(error));
        }
    }, [latitude, longitude]);





    if (!data || !data2) {
        return <div>Loading...</div>;
    }


    const temperatures = data2.map((datafore) => ({
        temperature : datafore.temperature ,
        time: datafore.time,
        icon: datafore.icon_name
    }));

    return (
        <>
            {/* <h1>My App</h1>
                {latitude && longitude ? (
                    <p>
                        Your location is: {latitude}, {longitude}
                    </p>
                ) : (
                    <p>Fetching your location...</p>
                )} */}


            <Top city={data.region}
                day={data.day}
                date={data.date}
                icon ={data.icon_name}
                temperature={data.temperature}
                temperatureMax={data.temperature_max}
                temperatureMin={data.temperature_min}
                weatherDescription={data.weather_description}
                winSpeed={data.wind_speed}
                rain={data.rain}
                sunrise={data.sunrise}
                sunset={data.sunset}
            />

        <Middle temperature={temperatures} />



        </>

    );
}


export default CompileWeather;