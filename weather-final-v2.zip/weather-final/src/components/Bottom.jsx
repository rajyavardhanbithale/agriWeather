import React from "react";

import './main.css'


function Bottom(props) {
    const { imageSrc } = props;
    return (
        <>
            <div className="next-5-days">
                <h2 className="next-5-days__heading">Next 5 days</h2>
                <div className="next-5-days__container">

                    <div className="next-5-days__row">

                        <div className="next-5-days__date">
                            Tue
                            <div className="next-5-days__label">30/7</div>
                        </div>

                        <div className="next-5-days__low">
                            10&deg;
                            <div className="next-5-days__label">Low</div>
                        </div>

                        <div className="next-5-days__high">
                            21&deg;
                            <div className="next-5-days__label">High</div>
                        </div>

                        <div className="next-5-days__icon">
                        <img src={imageSrc} alt="Mostly sunny" />
                        </div>

                        <div className="next-5-days__rain">
                            0%
                            <div className="next-5-days__label">Rain</div>
                        </div>

                        <div className="next-5-days__wind">
                            12mph
                            <div className="next-5-days__label">Wind</div>
                        </div>

                    </div>

                </div>
            </div>

        </>
    )
}


export default Bottom;